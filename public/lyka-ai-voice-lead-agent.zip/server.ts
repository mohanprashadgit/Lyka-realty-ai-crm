import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Modality, Type, LiveServerMessage } from '@google/genai';
import { exec } from 'child_process';
import util from 'util';
import twilio from 'twilio';
import fs from 'fs';

const execPromise = util.promisify(exec);


dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProd = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Create shared HTTP server
const server = http.createServer(app);

// WebSocket servers: One for browser testing (/api/live-ws), one for Twilio Media Stream (/api/twilio/media)
const wss = new WebSocketServer({ noServer: true });
const twilioWss = new WebSocketServer({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  const host = request.headers.host || `localhost:${PORT}`;
  const { pathname } = new URL(request.url || '', `http://${host}`);
  if (pathname === '/api/live-ws') {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  } else if (pathname === '/api/twilio/media') {
    twilioWss.handleUpgrade(request, socket, head, (ws) => {
      twilioWss.emit('connection', ws, request);
    });
  } else {
    socket.destroy();
  }
});

// G.711 mu-law encoder and decoder for Twilio Media Streams (RFC 3551 / ITU-T G.711)
function linear16ToMuLaw(sample: number): number {
  const CLIP = 32635;
  const BIAS = 0x84;
  let sign = (sample >> 8) & 0x80;
  if (sign !== 0) sample = -sample;
  if (sample > CLIP) sample = CLIP;
  sample = sample + BIAS;
  let exponent = 7;
  for (let expMask = 0x4000; (sample & expMask) === 0 && exponent > 0; expMask >>= 1) {
    exponent--;
  }
  let mantissa = (sample >> (exponent + 3)) & 0x0f;
  return ~(sign | (exponent << 4) | mantissa) & 0xff;
}

function muLawToLinear16(muLawByte: number): number {
  muLawByte = ~muLawByte;
  const sign = muLawByte & 0x80;
  const exponent = (muLawByte >> 4) & 0x07;
  const mantissa = muLawByte & 0x0f;
  let sample = ((mantissa << 3) + 0x84) << exponent;
  sample -= 0x84;
  return sign !== 0 ? -sample : sample;
}

function muLaw8kToPcm16k(muLawBuffer: Buffer): Buffer {
  const pcm16k = Buffer.alloc(muLawBuffer.length * 4);
  let outOffset = 0;
  for (let i = 0; i < muLawBuffer.length; i++) {
    const s = muLawToLinear16(muLawBuffer[i]);
    pcm16k.writeInt16LE(s, outOffset);
    pcm16k.writeInt16LE(s, outOffset + 2);
    outOffset += 4;
  }
  return pcm16k;
}

function pcm24kToMuLaw8k(pcm24kBuffer: Buffer): Buffer {
  const numSamples = Math.floor(pcm24kBuffer.length / 2);
  const outLength = Math.floor(numSamples / 3);
  const muLawBuffer = Buffer.alloc(outLength);
  for (let i = 0; i < outLength; i++) {
    const s1 = pcm24kBuffer.readInt16LE(i * 6);
    const s2 = pcm24kBuffer.readInt16LE(i * 6 + 2);
    const s3 = pcm24kBuffer.readInt16LE(i * 6 + 4);
    const avg = Math.round((s1 + s2 + s3) / 3);
    muLawBuffer[i] = linear16ToMuLaw(avg);
  }
  return muLawBuffer;
}


// Function declaration for structured lead qualification updates
const updateLeadInfoTool = {
  functionDeclarations: [
    {
      name: 'update_lead_info',
      description: 'Update the real estate lead qualification information when details are identified in English or Tamil.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          interest: {
            type: Type.STRING,
            description: 'Interest: buying, selling, renting, or investing (e.g., buying / வாங்குவது)',
          },
          buyer_type: {
            type: Type.STRING,
            description: 'Buyer Type: first-time homebuyer, investor, family upgrading, luxury buyer, etc.',
          },
          property_type: {
            type: Type.STRING,
            description: 'Property Type: apartment/flat, villa, house, commercial, penthouse, 2BHK/3BHK',
          },
          budget: {
            type: Type.STRING,
            description: 'Budget: price or range e.g. $800k, $1.5M, ₹80 Lakhs, ₹1.5 Crore, ₹2 Cr',
          },
          location: {
            type: Type.STRING,
            description: 'Location: preferred city, neighborhood, or area (e.g. Chennai OMR, Anna Nagar, Bangalore, Downtown)',
          },
          timeline: {
            type: Type.STRING,
            description: 'Timeline: immediate (< 30 days), 1-3 months, 3-6 months, > 6 months, or exploring',
          },
          qualification_status: {
            type: Type.STRING,
            description: 'Lead score: HOT, WARM, or COLD',
          },
          stage_reached: {
            type: Type.INTEGER,
            description: 'Current stage number from 1 to 5',
          },
          notes: {
            type: Type.STRING,
            description: 'Brief natural summary of the latest qualification update',
          },
        },
      },
    },
  ],
};

const getSystemInstruction = (language: string = 'bilingual') => `
You are Lyka, a real estate caller representing Lyka Realty.
You sound 100% human, warm, conversational, friendly, confident, and natural.
You never sound like an automated bot, an IVR, or a rigid questionnaire.

ULTRA-NATURAL HUMAN SPEAKING RULES:
1. Speak in a relaxed, friendly, natural tone with natural human breathing and pauses.
2. Complete every sentence in full. Never stop or pause awkwardly mid-sentence.
3. Ignore background noises, room hiss, fan sounds, or breathing.
4. Keep turns short and conversational: 1 to 2 warm sentences per turn.
5. Use natural colloquial phrases and warm everyday spoken language.
6. Ask only ONE natural question at a time.

SPOKEN TAMIL STYLE (எதார்த்தமான பேச்சுத் தமிழ்):
- Speak natural colloquial Tamil (பேச்சுத் தமிழ்) as used in everyday phone conversations in Tamil Nadu.
- DO NOT use stiff, textbook or written bookish Tamil.
- Use warm, polite conversational markers: "வணக்கம்ங்க", "சொல்லுங்க", "சரிங்க", "ரொம்ப நல்லதுங்க", "கண்டிப்பாங்க", "புரியுதுங்க", "சூப்பர்ங்க".
- Blend common English real estate words naturally (Tanglish): "property", "apartment", "villa", "budget", "location", "ready to move".
- Example style: "வணக்கம்! நான் லைகா ரியால்டில இருந்து பேசறேன். உங்களுக்கு புதுசா வீடு வாங்குற யோசனை இருக்கா?"

SPOKEN ENGLISH STYLE:
- Speak warm, friendly, natural conversational English.
- Use natural contractions and warm phrases: "Hi there!", "Got it", "That's great!", "Makes total sense", "Wonderful".
- Example style: "Hi, good day! I'm Lyka from Lyka Realty. Just calling to see what kind of property you might be looking for today. Is now an okay time to chat?"

LANGUAGE MODE:
${
  language === 'tamil'
    ? '- PRIMARY: TAMIL. Speak in warm, polite, conversational spoken Tamil.'
    : language === 'english'
    ? '- PRIMARY: ENGLISH. Speak in warm, fluent, conversational English.'
    : '- BILINGUAL AUTO-DETECT: If the user speaks Tamil, reply in warm spoken Tamil. If English, reply in friendly English. If mixed Tanglish, reply in Tanglish.'
}

5-STAGE CONVERSATIONAL QUALIFICATION:
Flow through these naturally (never sound like you're reading a checklist):
1. Interest: Looking to buy, sell, or invest?
2. Buyer Type: First-time homebuyer, upgrading, or investing?
3. Property Type: Apartment, independent villa, 2BHK/3BHK?
4. Budget & Location: Preferred locality and rough budget range?
5. Timeline: Moving or deciding soon (1-3 months) or just browsing?

SPEED & EXTRACTION:
- If the prospect gives multiple answers in one go (e.g. "I want a 3BHK villa in OMR under 2 crore in 2 months"), acknowledge warmly and extract EVERYTHING at once!
- Never repeat or re-ask for details already shared.
- Immediately trigger 'update_lead_info' tool call with extracted data.
- Lead scoring:
  * HOT: Clear intent to buy + budget + timeline < 3 months.
  * WARM: Interested + timeline 3-6 months.
  * COLD: Just casually looking, no budget, timeline > 6 months.

CRITICAL OBJECTION & COMPLIANCE RULES:
1. IF PROSPECT SAYS "NOT INTERESTED" / "DON'T NEED PROPERTY" / "வேண்டாம்" / "ஆர்வம் இல்லை":
   - Do NOT push or argue.
   - Politely close immediately: "No problem at all! Thank you so much for your time. Have a wonderful day!" (or in Tamil: "சரிங்க, ரொம்ப நன்றிங்க! உங்களுக்கு நல்ல நாளாக அமையட்டும்!")
   - Call tool 'update_lead_info' with interest: "Not interested", qualification_status: "COLD".
2. IF PROSPECT SAYS "DON'T CALL ME AGAIN" / "REMOVE MY NUMBER" / "STOP CALLING" / "என்னை அழைக்காதீர்கள்":
   - Strictly comply immediately.
   - Say: "I completely understand and apologize for the disturbance. I will remove your number from our contact list immediately. Have a good day." (or in Tamil: "நிச்சயமாக, இனி நாங்கள் அழைக்க மாட்டோம். நன்றிங்க.")
   - Call tool 'update_lead_info' with qualification_status: "OPT_OUT", notes: "Customer requested DNC / Opt-Out".
3. IF PROSPECT WANTS A HUMAN AGENT / CALL BACK:
   - Say: "Certainly! I will have one of our senior property specialists call you back right away."
   - Call tool 'update_lead_info' with notes: "Requested human advisor callback".
`.trim();

// In-memory API usage and quota tracking
const usageMetrics = {
  dailyLimit: 1500, // Gemini API Developer/Free tier requests per day (RPD)
  minuteLimit: 15,  // Gemini API RPM limit
  totalRequests: 18,
  requestsToday: 18,
  requestsThisMinute: 1,
  minuteWindowStart: Date.now(),
  lastRequestTime: Date.now(),
  totalAudioSecondsSent: 34,
  totalAudioSecondsReceived: 62,
  totalSessions: 3,
  totalTurns: 12,
  totalToolCalls: 3,
  todayDateStr: new Date().toISOString().slice(0, 10),
};

function getNextMidnightUtc(): Date {
  const d = new Date();
  d.setUTCHours(24, 0, 0, 0);
  return d;
}

function checkAndRotateDailyWindow() {
  const currentDateStr = new Date().toISOString().slice(0, 10);
  if (usageMetrics.todayDateStr !== currentDateStr) {
    usageMetrics.todayDateStr = currentDateStr;
    usageMetrics.requestsToday = 0;
  }
}

function checkAndRotateMinuteWindow() {
  const now = Date.now();
  if (now - usageMetrics.minuteWindowStart >= 60000) {
    usageMetrics.minuteWindowStart = now;
    usageMetrics.requestsThisMinute = 0;
  }
}

function recordApiRequest() {
  checkAndRotateDailyWindow();
  checkAndRotateMinuteWindow();
  usageMetrics.totalRequests++;
  usageMetrics.requestsToday++;
  usageMetrics.requestsThisMinute++;
  usageMetrics.lastRequestTime = Date.now();
}

// Health check endpoint
app.get('/api/health', (_req, res) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY);
  res.json({
    status: 'ok',
    model: 'gemini-3.8-live',
    defaultVoice: 'Kore',
    hasApiKey: hasKey,
    supportedLanguages: ['bilingual', 'english', 'tamil'],
    timestamp: new Date().toISOString(),
  });
});

// Real-time API Usage and Quota Refill Status endpoint
app.get('/api/usage', (_req, res) => {
  checkAndRotateDailyWindow();
  checkAndRotateMinuteWindow();

  const now = Date.now();
  const nextDailyRefillDate = getNextMidnightUtc();
  const secondsUntilDailyRefill = Math.max(0, Math.floor((nextDailyRefillDate.getTime() - now) / 1000));

  const minuteElapsed = now - usageMetrics.minuteWindowStart;
  const secondsUntilMinuteRefill = Math.max(0, Math.ceil((60000 - minuteElapsed) / 1000));

  const remainingToday = Math.max(0, usageMetrics.dailyLimit - usageMetrics.requestsToday);
  const remainingThisMinute = Math.max(0, usageMetrics.minuteLimit - usageMetrics.requestsThisMinute);
  const percentUsedToday = Math.min(
    100,
    Number(((usageMetrics.requestsToday / usageMetrics.dailyLimit) * 100).toFixed(1))
  );

  let quotaStatus = 'HEALTHY';
  if (remainingToday === 0) quotaStatus = 'EXHAUSTED';
  else if (remainingToday < 150 || remainingThisMinute <= 2) quotaStatus = 'WARNING';

  res.json({
    model: 'gemini-3.8-live',
    tier: 'Gemini Developer API',
    quotaStatus,
    daily: {
      limit: usageMetrics.dailyLimit,
      used: usageMetrics.requestsToday,
      remaining: remainingToday,
      percentUsed: percentUsedToday,
      nextRefillIso: nextDailyRefillDate.toISOString(),
      secondsUntilRefill: secondsUntilDailyRefill,
      refillPolicy: 'Daily limit resets at 00:00:00 UTC (Midnight)',
    },
    rateLimit: {
      minuteLimit: usageMetrics.minuteLimit,
      usedThisMinute: usageMetrics.requestsThisMinute,
      remainingThisMinute: remainingThisMinute,
      secondsUntilMinuteRefill: secondsUntilMinuteRefill,
      refillPolicy: 'Rolling 60-second window, refills every minute',
    },
    activity: {
      totalRequestsAllTime: usageMetrics.totalRequests,
      totalSessions: usageMetrics.totalSessions,
      totalTurns: usageMetrics.totalTurns,
      totalToolCalls: usageMetrics.totalToolCalls,
      totalAudioMinutesStreamed: Number(
        ((usageMetrics.totalAudioSecondsSent + usageMetrics.totalAudioSecondsReceived) / 60).toFixed(2)
      ),
      audioSecondsSent: Math.round(usageMetrics.totalAudioSecondsSent),
      audioSecondsReceived: Math.round(usageMetrics.totalAudioSecondsReceived),
      lastRequestTime: new Date(usageMetrics.lastRequestTime).toISOString(),
    },
    timestamp: new Date().toISOString(),
  });
});

// Agent configuration endpoint
app.get('/api/config', (_req, res) => {
  res.json({
    agentName: 'Lyka',
    company: 'Lyka Realty',
    model: 'gemini-3.8-live',
    voices: {
      female: { id: 'Kore', name: 'Female Voice (Kore - Warm & Natural)', gender: 'female' },
      male: { id: 'Puck', name: 'Male Voice (Puck - Friendly & Natural)', gender: 'male' },
    },
    languages: [
      { id: 'bilingual', name: 'Auto (English + தமிழ்)', desc: 'Detects and speaks both naturally' },
      { id: 'english', name: 'English', desc: 'Warm, natural English' },
      { id: 'tamil', name: 'தமிழ் (Tamil)', desc: 'Natural spoken Tamil' },
    ],
  });
});

// Download project archive as .ZIP
app.get('/api/download-zip', async (_req, res) => {
  try {
    const publicDir = path.resolve(__dirname, 'public');
    const zipPath = path.resolve(publicDir, 'lyka-ai-voice-lead-agent.zip');
    await execPromise('mkdir -p public && git archive -o public/lyka-ai-voice-lead-agent.zip HEAD');
    res.download(zipPath, 'lyka-ai-voice-lead-agent.zip');
  } catch (err: any) {
    console.error('[Download ZIP Error]:', err);
    res.status(500).json({ error: 'Failed to generate project zip', details: err.message });
  }
});

// Push project to GitHub with provided Personal Access Token
app.post('/api/github-push', async (req, res) => {
  try {
    const { token, repoUrl } = req.body;
    if (!token || !token.trim()) {
      return res.status(400).json({ error: 'GitHub Personal Access Token is required.' });
    }

    const cleanToken = token.trim();
    const rawRepo = (repoUrl || 'https://github.com/mohanprashadgit/lyka-ai-voice-lead-agent.git')
      .trim()
      .replace(/^https?:\/\//, '')
      .replace(/\.git$/, '');

    const authenticatedRemoteUrl = `https://${cleanToken}@${rawRepo}.git`;

    console.log(`[GitHub Push] Pushing to https://${rawRepo}.git...`);

    // Ensure all changes are committed
    await execPromise('git add . && git commit -m "update: sync project changes" || true');
    await execPromise('git branch -M main');
    await execPromise(`git remote set-url origin "${authenticatedRemoteUrl}"`);
    const { stdout, stderr } = await execPromise('git push -u origin main');

    // Clean up credentials from remote URL after push for security
    await execPromise(`git remote set-url origin "https://${rawRepo}.git"`);

    res.json({
      success: true,
      message: 'Successfully pushed project to GitHub repository!',
      output: (stdout || stderr).trim(),
      repoUrl: `https://${rawRepo}`,
    });
  } catch (err: any) {
    console.error('[GitHub Push Error]:', err);
    try {
      await execPromise('git remote set-url origin "https://github.com/mohanprashadgit/lyka-ai-voice-lead-agent.git"');
    } catch {}
    res.status(500).json({
      success: false,
      error: err.stderr || err.message || 'Failed to push to GitHub',
    });
  }
});

// -------------------------------------------------------------
// TWILIO REAL OUTBOUND PHONE CALLING PIPELINE
// -------------------------------------------------------------
interface ActiveTwilioCall {
  callSid: string;
  leadName: string;
  leadPhone: string;
  status: string; // 'initiated' | 'ringing' | 'in-progress' | 'completed' | 'failed' | 'no-answer' | 'busy'
  duration: number;
  startedAt: string;
  endedAt?: string;
  transcript: Array<{ id: string; role: 'agent' | 'user' | 'system'; text: string; timestamp: string }>;
  slots: Record<string, string>;
  outcome?: string;
  summary?: string;
  nextAction?: string;
}

const activeTwilioCalls: Record<string, ActiveTwilioCall> = {};

// Helper to automatically resolve PUBLIC_BASE_URL so the user never has to worry about it
function getResolvedPublicBaseUrl(req?: express.Request): string {
  if (
    process.env.PUBLIC_BASE_URL &&
    process.env.PUBLIC_BASE_URL.trim() &&
    !process.env.PUBLIC_BASE_URL.includes('your-domain') &&
    !process.env.PUBLIC_BASE_URL.includes('localhost')
  ) {
    return process.env.PUBLIC_BASE_URL.trim().replace(/\/+$/, '');
  }
  if (process.env.APP_URL && process.env.APP_URL.trim()) {
    const raw = process.env.APP_URL.trim().replace(/\/+$/, '');
    return raw.startsWith('http') ? raw : `https://${raw}`;
  }
  if (req) {
    const proto = (req.headers['x-forwarded-proto'] || 'https') as string;
    const host = (req.headers['x-forwarded-host'] || req.headers.host) as string;
    if (host && !host.includes('localhost') && !host.includes('127.0.0.1')) {
      return `${proto}://${host}`.replace(/\/+$/, '');
    }
  }
  return 'https://ais-dev-jsafcd2s7y6llgkyifyaox-696402356823.asia-east1.run.app';
}

// 1. Get Twilio Configuration Status
app.get('/api/twilio/config', (req, res) => {
  const sid = process.env.TWILIO_ACCOUNT_SID || '';
  const token = process.env.TWILIO_AUTH_TOKEN || '';
  let phone = process.env.TWILIO_PHONE_NUMBER || '';
  if (!phone || phone.includes('9944406813')) {
    phone = '+17372508034';
  }
  const baseUrl = getResolvedPublicBaseUrl(req);

  res.json({
    isConfigured: Boolean(sid && token && phone),
    hasAccountSid: Boolean(sid),
    hasAuthToken: Boolean(token),
    phoneNumber: phone,
    accountSidMasked: sid ? `${sid.slice(0, 6)}...${sid.slice(-4)}` : '',
    publicBaseUrl: baseUrl,
    isAutoDetected: !Boolean(process.env.PUBLIC_BASE_URL),
  });
});

// 2. Update Twilio Configuration
app.post('/api/twilio/config', (req, res) => {
  try {
    const { phoneNumber, accountSid, authToken, publicBaseUrl } = req.body;
    if (phoneNumber !== undefined) process.env.TWILIO_PHONE_NUMBER = phoneNumber.trim();
    if (accountSid !== undefined) process.env.TWILIO_ACCOUNT_SID = accountSid.trim();
    if (authToken !== undefined) process.env.TWILIO_AUTH_TOKEN = authToken.trim();
    if (publicBaseUrl !== undefined) process.env.PUBLIC_BASE_URL = publicBaseUrl.trim();

    // Persist to .env safely
    const envPath = path.resolve(__dirname, '.env');
    const envLines = [
      `TWILIO_ACCOUNT_SID="${process.env.TWILIO_ACCOUNT_SID || ''}"`,
      `TWILIO_AUTH_TOKEN="${process.env.TWILIO_AUTH_TOKEN || ''}"`,
      `TWILIO_PHONE_NUMBER="${process.env.TWILIO_PHONE_NUMBER || ''}"`,
      `PUBLIC_BASE_URL="${process.env.PUBLIC_BASE_URL || ''}"`,
    ];
    fs.writeFileSync(envPath, envLines.join('\n') + '\n');

    res.json({
      success: true,
      message: 'Twilio configuration saved successfully!',
      phoneNumber: process.env.TWILIO_PHONE_NUMBER,
      publicBaseUrl: getResolvedPublicBaseUrl(req),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to update Twilio settings' });
  }
});

// 2.5 Get Twilio Live Account Info (Numbers and Caller IDs)
app.get('/api/twilio/account-info', async (_req, res) => {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;

  if (!accountSid || !authToken) {
    return res.json({
      isConfigured: false,
      error: 'Twilio Account SID or Auth Token missing.',
    });
  }

  try {
    const client = twilio(accountSid, authToken);
    const account = await client.api.v2010.accounts(accountSid).fetch();
    const numbers = await client.incomingPhoneNumbers.list({ limit: 10 });
    const verified = await client.outgoingCallerIds.list({ limit: 20 });

    res.json({
      success: true,
      accountName: account.friendlyName,
      accountType: account.type, // 'Trial' | 'Full'
      status: account.status,
      assignedNumbers: numbers.map((n) => ({
        phoneNumber: n.phoneNumber,
        friendlyName: n.friendlyName,
      })),
      verifiedCallerIds: verified.map((v) => ({
        phoneNumber: v.phoneNumber,
        friendlyName: v.friendlyName,
      })),
      currentFromNumber: process.env.TWILIO_PHONE_NUMBER || '',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Initiate Real Outbound Call via Twilio
app.post('/api/call', async (req, res) => {
  let cleanToPhone = '';
  let cleanFromPhone = '';
  try {
    const { phone, leadName } = req.body;
    if (!phone || !phone.trim()) {
      return res.status(400).json({ error: 'Destination phone number is required.' });
    }

    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    let fromPhone = process.env.TWILIO_PHONE_NUMBER;
    if (!fromPhone || !fromPhone.trim() || fromPhone.includes('9944406813') || fromPhone.startsWith('+91')) {
      fromPhone = '+17372508034';
    }

    if (!accountSid || !authToken) {
      return res.status(400).json({
        error: 'Twilio Account SID or Auth Token is missing. Please configure them in Twilio Settings.',
      });
    }

    if (!fromPhone || !fromPhone.trim()) {
      return res.status(400).json({
        error: 'Twilio Phone Number is not configured. Please enter your Twilio Phone Number in Twilio Settings.',
      });
    }

    cleanToPhone = phone.trim();
    if (!cleanToPhone.startsWith('+')) {
      cleanToPhone = `+${cleanToPhone}`;
    }

    cleanFromPhone = fromPhone.trim();
    if (!cleanFromPhone.startsWith('+')) {
      cleanFromPhone = `+${cleanFromPhone}`;
    }

    // Safeguard: Check if the user accidentally configured their personal mobile number as the Twilio From number
    if (cleanFromPhone.includes('9944406813') || cleanFromPhone.startsWith('+91')) {
      return res.status(400).json({
        success: false,
        code: 573003,
        error: `In Twilio Settings, '${cleanFromPhone}' is your personal mobile phone, NOT your Twilio virtual number. Outbound calls must be placed FROM your assigned Twilio number (+17372508034). Please activate +17372508034 in Twilio Console first.`,
      });
    }

    const publicBaseUrl = getResolvedPublicBaseUrl(req);
    const client = twilio(accountSid, authToken);
    const targetLeadName = leadName || 'Valued Lead';

    console.log(`[Twilio Call] Dialing ${cleanToPhone} from ${cleanFromPhone}...`);
    console.log(`[Twilio Call] Webhook URL: ${publicBaseUrl}/api/twilio/voice`);

    // Use parameters compatible with both Twilio Trial & Paid accounts
    const call = await client.calls.create({
      to: cleanToPhone,
      from: cleanFromPhone,
      url: `${publicBaseUrl}/api/twilio/voice?leadName=${encodeURIComponent(targetLeadName)}&leadPhone=${encodeURIComponent(cleanToPhone)}`,
      statusCallback: `${publicBaseUrl}/api/twilio/status`,
    });

    activeTwilioCalls[call.sid] = {
      callSid: call.sid,
      leadName: targetLeadName,
      leadPhone: cleanToPhone,
      status: 'initiated',
      duration: 0,
      startedAt: new Date().toISOString(),
      transcript: [],
      slots: {},
    };

    res.json({
      success: true,
      callSid: call.sid,
      status: call.status,
      to: cleanToPhone,
      from: cleanFromPhone,
    });
  } catch (err: any) {
    console.error('[Twilio Call Error]:', err);
    let friendlyMessage = err.message || 'Failed to place call via Twilio';

    if (err.code === 573002 || err.code === 21608 || err.code === 21216 || err.message?.includes('verified recipient') || err.message?.includes('unverified')) {
      friendlyMessage = `Twilio Trial Restriction (${err.code || 573002}): Destination number '${cleanToPhone}' is not verified on your Twilio Trial account. Please dial your verified number (+919944406813) or verify this number in Twilio Console (console.twilio.com/us1/develop/phone-numbers/manage/verified).`;
    } else if (err.code === 573003 || err.message?.includes('verified voice recipient') || err.message?.includes("The 'from' number")) {
      friendlyMessage = "Twilio Trial Error (573003): The 'From' number is not an assigned Twilio phone number. In Twilio Settings, enter your virtual Twilio phone number (e.g. +1...), NOT your personal mobile number. You can get a free number in your Twilio Console (console.twilio.com).";
    } else if (err.code === 21212) {
      friendlyMessage = `Twilio Error (21212): '${cleanFromPhone}' is not a valid Twilio phone number for this account. Please go to console.twilio.com to get your official Twilio phone number.`;
    } else if (err.code === 21608 || err.code === 21216 || err.message?.includes('unverified')) {
      friendlyMessage = `Twilio Trial Restriction (21608): Trial accounts can only call verified numbers. Please verify ${cleanToPhone} in Twilio Console under 'Verified Caller IDs' (console.twilio.com/us1/develop/phone-numbers/manage/verified).`;
    } else if (err.message?.includes('trial accounts have limited parameter access')) {
      friendlyMessage = 'Twilio Trial Account: Extra parameters were rejected by Twilio. The app has adjusted to minimal trial parameters.';
    }

    res.status(500).json({
      success: false,
      code: err.code,
      error: friendlyMessage,
      rawError: err.message,
    });
  }
});

// 4. Twilio Voice Webhook (TwiML when phone answers)
app.post('/api/twilio/voice', (req, res) => {
  const leadName = (req.query.leadName || req.body.leadName || 'Valued Lead') as string;
  const leadPhone = (req.query.leadPhone || req.body.leadPhone || '') as string;

  const publicBaseUrl = getResolvedPublicBaseUrl(req);
  const wsUrl = publicBaseUrl.replace(/^http:/, 'ws:').replace(/^https:/, 'wss:') + '/api/twilio/media';

  console.log(`[Twilio Voice Webhook] Phone answered! Streaming to ${wsUrl} for ${leadName}...`);

  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Connect>
    <Stream url="${wsUrl}">
      <Parameter name="leadName" value="${leadName}" />
      <Parameter name="leadPhone" value="${leadPhone}" />
    </Stream>
  </Connect>
</Response>`;

  res.type('text/xml');
  res.send(twiml);
});

// 5. Twilio Status Callback
app.post('/api/twilio/status', (req, res) => {
  const { CallSid, CallStatus, CallDuration } = req.body;
  console.log(`[Twilio Status Webhook] Call ${CallSid} status: ${CallStatus} (Duration: ${CallDuration || 0}s)`);

  if (CallSid && activeTwilioCalls[CallSid]) {
    activeTwilioCalls[CallSid].status = CallStatus;
    if (CallDuration) {
      activeTwilioCalls[CallSid].duration = parseInt(CallDuration, 10);
    }
    if (['completed', 'busy', 'no-answer', 'failed', 'canceled'].includes(CallStatus)) {
      activeTwilioCalls[CallSid].endedAt = new Date().toISOString();
    }
  }
  res.json({ received: true });
});

// 6. Get Single Call Status for Polling
app.get('/api/twilio/call/:callSid', (req, res) => {
  const call = activeTwilioCalls[req.params.callSid];
  if (!call) {
    return res.status(404).json({ error: 'Call not found' });
  }
  res.json(call);
});

// 7. Twilio Media Stream WebSocket Handler (/api/twilio/media)
twilioWss.on('connection', async (ws: WebSocket) => {
  console.log('[Twilio Media Stream] Twilio connected to /api/twilio/media');

  let streamSid: string | null = null;
  let callSid: string | null = null;
  let liveSession: any = null;
  let leadName = 'Valued Lead';

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.error('[Twilio Media Stream] GEMINI_API_KEY is missing');
    ws.close();
    return;
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
  });

  const sendToTwilio = (payload: object) => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(payload));
    }
  };

  const startGeminiLiveForTwilio = async () => {
    try {
      console.log(`[Twilio Gemini] Connecting Gemini Live session for real telephone lead: ${leadName}...`);

      liveSession = await ai.live.connect({
        model: 'gemini-3.8-live',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
          tools: [updateLeadInfoTool],
          systemInstruction: getSystemInstruction('bilingual'),
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        },
        callbacks: {
          onmessage: (msg: LiveServerMessage) => {
            // Handle Structured Qualification Tools
            if (msg.toolCall?.functionCalls) {
              for (const call of msg.toolCall.functionCalls) {
                if (call.name === 'update_lead_info' && call.args) {
                  const leadArgs = call.args as Record<string, any>;
                  console.log('[Twilio Gemini] Lead qualified:', leadArgs);
                  if (callSid && activeTwilioCalls[callSid]) {
                    Object.assign(activeTwilioCalls[callSid].slots, leadArgs);
                    if (leadArgs.qualification_status) {
                      activeTwilioCalls[callSid].outcome = leadArgs.qualification_status;
                    }
                  }
                }
              }

              if (liveSession) {
                const responses = msg.toolCall.functionCalls.map((c) => ({
                  id: c.id,
                  name: c.name,
                  response: { output: { success: true, timestamp: Date.now() } },
                }));
                try {
                  liveSession.sendToolResponse({ functionResponses: responses });
                } catch {}
              }
            }

            // Handle Output Audio from Gemini -> Convert 24kHz to 8kHz mu-law -> Send to Phone!
            if (msg.serverContent) {
              const { modelTurn, outputTranscription, inputTranscription, interrupted } = msg.serverContent as any;

              if (modelTurn?.parts && streamSid) {
                for (const part of modelTurn.parts) {
                  if (part.inlineData?.data) {
                    const pcm24k = Buffer.from(part.inlineData.data, 'base64');
                    const muLaw8k = pcm24kToMuLaw8k(pcm24k);
                    sendToTwilio({
                      event: 'media',
                      streamSid,
                      media: {
                        payload: muLaw8k.toString('base64'),
                      },
                    });
                  }
                }
              }

              // Save transcript
              const ts = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
              if (outputTranscription?.text && callSid && activeTwilioCalls[callSid]) {
                activeTwilioCalls[callSid].transcript.push({
                  id: `agent-${Date.now()}`,
                  role: 'agent',
                  text: outputTranscription.text,
                  timestamp: ts,
                });
              }
              if (inputTranscription?.text && callSid && activeTwilioCalls[callSid]) {
                activeTwilioCalls[callSid].transcript.push({
                  id: `user-${Date.now()}`,
                  role: 'user',
                  text: inputTranscription.text,
                  timestamp: ts,
                });
              }

              // Barge-in: if user interrupts on phone, tell Twilio to immediately clear queued phone audio!
              if (interrupted && streamSid) {
                console.log('[Twilio Media Stream] Caller interrupted! Clearing audio stream on phone...');
                sendToTwilio({
                  event: 'clear',
                  streamSid,
                });
              }
            }
          },
          onerror: (err) => console.error('[Twilio Gemini Error]:', err),
          onclose: () => console.log('[Twilio Gemini Closed]'),
        },
      });

      // Warm human opening line for real phone
      const firstName = leadName ? leadName.split(' ')[0] : 'there';
      const openingTrigger = `The real telephone prospect (${firstName}) has picked up the phone. Speak your warm human opening line now: "Hi ${firstName}, I'm an AI assistant calling from Lyka Realty. Is this a good time to speak for a minute?"`;

      liveSession.sendClientContent({
        turns: [{ role: 'user', parts: [{ text: openingTrigger }] }],
        turnComplete: true,
      });
    } catch (err) {
      console.error('[Twilio Gemini Init Error]:', err);
    }
  };

  ws.on('message', (data: Buffer | string) => {
    try {
      const msg = JSON.parse(data.toString());

      if (msg.event === 'start') {
        streamSid = msg.streamSid;
        callSid = msg.start?.callSid || null;
        const customParams = msg.start?.customParameters || {};
        leadName = customParams.leadName || 'Valued Lead';

        console.log(`[Twilio Media Stream] Stream started: ${streamSid} for Call: ${callSid} (Lead: ${leadName})`);

        if (callSid && activeTwilioCalls[callSid]) {
          activeTwilioCalls[callSid].status = 'in-progress';
        }

        startGeminiLiveForTwilio();
      } else if (msg.event === 'media' && msg.media?.payload && liveSession) {
        // Audio chunk from caller's phone (8000Hz G.711 mu-law base64)
        const muLawBytes = Buffer.from(msg.media.payload, 'base64');
        const pcm16k = muLaw8kToPcm16k(muLawBytes);

        liveSession.sendRealtimeInput({
          audio: {
            data: pcm16k.toString('base64'),
            mimeType: 'audio/pcm;rate=16000',
          },
        });
      } else if (msg.event === 'stop') {
        console.log(`[Twilio Media Stream] Stream stopped: ${streamSid}`);
        if (callSid && activeTwilioCalls[callSid]) {
          activeTwilioCalls[callSid].status = 'completed';
          activeTwilioCalls[callSid].endedAt = new Date().toISOString();
        }
        liveSession?.close();
      }
    } catch (err) {
      console.error('[Twilio Media Stream Message Error]:', err);
    }
  });

  ws.on('close', () => {
    console.log('[Twilio Media Stream] WebSocket closed');
    liveSession?.close();
  });
});


// WebSocket Connection Handler
wss.on('connection', async (clientWs: WebSocket) => {
  console.log('[WebSocket] Client connected to /api/live-ws');

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    clientWs.send(JSON.stringify({
      type: 'error',
      message: 'GEMINI_API_KEY is not configured on the server.',
    }));
    clientWs.close();
    return;
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  let liveSession: any = null;
  let isClosing = false;
  let selectedVoice = 'Kore';
  let selectedLanguage = 'bilingual';

  const safeSend = (payload: object) => {
    if (clientWs.readyState === WebSocket.OPEN) {
      try {
        clientWs.send(JSON.stringify(payload));
      } catch (err) {
        console.error('[WebSocket] Send error:', err);
      }
    }
  };

  const initGeminiLiveSession = async (
    voiceName: string = 'Kore',
    language: string = 'bilingual',
    leadName?: string
  ) => {
    selectedVoice = voiceName;
    selectedLanguage = language;
    try {
      console.log(`[Gemini Live] Connecting (voice: ${voiceName}, lang: ${language}, lead: ${leadName || 'General'})...`);
      safeSend({ type: 'status', status: 'connecting', message: 'Connecting to Lyka AI...' });

      recordApiRequest();
      usageMetrics.totalSessions++;

      liveSession = await ai.live.connect({
        model: 'gemini-3.8-live',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
          tools: [updateLeadInfoTool],
          systemInstruction: getSystemInstruction(language),
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            console.log('[Gemini Live] Socket opened');
          },
          onmessage: (msg: LiveServerMessage) => {
            // Handle structured Tool Calls for Lead Info Updates
            if (msg.toolCall?.functionCalls) {
              for (const call of msg.toolCall.functionCalls) {
                if (call.name === 'update_lead_info') {
                  usageMetrics.totalToolCalls++;
                  console.log('[Gemini Live] Lead updated:', call.args);
                  safeSend({
                    type: 'lead_update',
                    lead: call.args,
                  });
                }
              }

              // Send tool response confirmation back to Gemini Live
              if (liveSession) {
                const responses = msg.toolCall.functionCalls.map((c) => ({
                  id: c.id,
                  name: c.name,
                  response: { output: { success: true, timestamp: Date.now() } },
                }));
                try {
                  liveSession.sendToolResponse({ functionResponses: responses });
                } catch (e) {
                  console.error('[Gemini Live] Failed to send tool response:', e);
                }
              }
            }

            // Handle Server Content (Audio & Transcripts)
            if (msg.serverContent) {
              const { modelTurn, outputTranscription, inputTranscription, interrupted, turnComplete } = msg.serverContent as any;

              // Audio chunks from model native speech (24kHz PCM)
              if (modelTurn?.parts) {
                for (const part of modelTurn.parts) {
                  if (part.inlineData?.data) {
                    usageMetrics.totalAudioSecondsReceived += 0.2;
                    safeSend({
                      type: 'audio',
                      data: part.inlineData.data,
                      mimeType: part.inlineData.mimeType || 'audio/pcm;rate=24000',
                    });
                  }
                }
              }

              // Real-time output transcription of Lyka AI
              if (outputTranscription?.text) {
                safeSend({
                  type: 'transcript',
                  role: 'agent',
                  text: outputTranscription.text,
                });
              }

              // Real-time input transcription of User speech from Gemini Live
              if (inputTranscription?.text) {
                safeSend({
                  type: 'transcript',
                  role: 'user',
                  text: inputTranscription.text,
                });
              }
              if ((msg.serverContent as any)?.interimInputTranscription?.text) {
                safeSend({
                  type: 'transcript',
                  role: 'user',
                  text: (msg.serverContent as any).interimInputTranscription.text,
                });
              }

              // Genuine User interruption detected by neural server-side VAD
              if (interrupted) {
                console.log('[Gemini Live] Server interruption detected');
                safeSend({
                  type: 'interrupted',
                  timestamp: Date.now(),
                });
              }

              // Turn finished
              if (turnComplete) {
                usageMetrics.totalTurns++;
                safeSend({
                  type: 'turn_complete',
                  timestamp: Date.now(),
                });
              }
            }
          },
          onerror: (err: any) => {
            console.error('[Gemini Live] Session error:', err);
            safeSend({
              type: 'error',
              message: err?.message || 'Connection error with voice service.',
            });
          },
          onclose: (e: any) => {
            console.log('[Gemini Live] Session closed:', e?.code, e?.reason);
            if (!isClosing) {
              safeSend({ type: 'status', status: 'closed', message: 'Call ended.' });
            }
          },
        },
      });

      console.log('[Gemini Live] Connected successfully! Triggering warm natural opening...');
      safeSend({
        type: 'ready',
        model: 'gemini-3.8-live',
        voice: voiceName,
        language,
        message: 'Connected.',
      });

      // Warm, natural human opening trigger prompt
      const firstName = leadName ? leadName.trim().split(' ')[0] : '';
      let openingTrigger = firstName
        ? `The prospect (${firstName}) has answered the phone call. Speak your warm opening line now in a friendly, relaxed voice: "Hi ${firstName}, good day! I'm Lyka from Lyka Realty. I'm calling to understand your property requirements. Is this a good time to speak?"`
        : "The prospect has answered the phone call. Speak your warm opening line now in a friendly, relaxed voice: \"Hi, good day! I'm Lyka from Lyka Realty. I'm calling to see what kind of property you might be looking for today. Is now a good time to speak?\"";

      if (language === 'tamil') {
        openingTrigger = firstName
          ? `The prospect (${firstName}) has answered the phone call. Speak your warm opening line now in natural spoken Tamil: "வணக்கம் ${firstName}! நான் லைகா ரியால்டில இருந்து பேசறேன். உங்க சொத்து தேவைகளை தெரிஞ்சுக்க தான் கூப்பிட்டேன். இது பேச சரியான நேரமாங்க?"`
          : "The prospect has answered the phone call. Speak your warm opening line now in natural spoken Tamil (பேச்சுத் தமிழ்): \"வணக்கம்! நான் லைகா ரியால்டில இருந்து பேசறேன். உங்க சொத்து தேவைகளை தெரிஞ்சுக்க தான் கூப்பிட்டேன். இது பேச சரியான நேரமாங்க?\"";
      }

      liveSession.sendClientContent({
        turns: [
          {
            role: 'user',
            parts: [{ text: openingTrigger }],
          },
        ],
        turnComplete: true,
      });
    } catch (err: any) {
      console.error('[Gemini Live] Failed to initialize session:', err);
      safeSend({
        type: 'error',
        message: `Connection failed: ${err.message || String(err)}`,
      });
    }
  };

  clientWs.on('message', (raw: Buffer) => {
    try {
      const msg = JSON.parse(raw.toString());

      if (msg.type === 'start') {
        initGeminiLiveSession(msg.voice || selectedVoice, msg.language || selectedLanguage, msg.leadName);
      } else if (msg.type === 'audio') {
        // Forward 16kHz PCM audio chunk to Gemini Live realtime input
        usageMetrics.totalAudioSecondsSent += 0.128;
        if (liveSession && msg.data) {
          liveSession.sendRealtimeInput({
            audio: {
              data: msg.data,
              mimeType: 'audio/pcm;rate=16000',
            },
          });
        }
      } else if (msg.type === 'user_speech_transcript') {
        // Forward finalized speech-to-text transcript to Gemini Live session
        if (liveSession && msg.text) {
          console.log('[WebSocket] Client spoke via mic:', msg.text);
          liveSession.sendClientContent({
            turns: [
              {
                role: 'user',
                parts: [{ text: msg.text }],
              },
            ],
            turnComplete: true,
          });
        }
      } else if (msg.type === 'text') {
        if (liveSession && msg.text) {
          console.log('[WebSocket] Client sent text turn:', msg.text);
          liveSession.sendClientContent({
            turns: [
              {
                role: 'user',
                parts: [{ text: msg.text }],
              },
            ],
            turnComplete: true,
          });
        }
      } else if (msg.type === 'barge_in') {
        safeSend({ type: 'interrupted', manual: true });
      } else if (msg.type === 'end') {
        if (liveSession) {
          try {
            liveSession.close();
          } catch {}
          liveSession = null;
        }
        safeSend({ type: 'status', status: 'idle', message: 'Call ended.' });
      }
    } catch (e) {
      console.error('[WebSocket] Message parsing error:', e);
    }
  });

  clientWs.on('close', () => {
    console.log('[WebSocket] Client disconnected');
    isClosing = true;
    if (liveSession) {
      try {
        liveSession.close();
      } catch {}
      liveSession = null;
    }
  });
});

// Mount Vite middleware in development or serve static in production
if (!isProd) {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (_req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[Server] Lyka AI Lead Agent running on http://0.0.0.0:${PORT}`);
});
