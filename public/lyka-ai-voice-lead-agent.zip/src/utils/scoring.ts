import { LeadData, LeadOutcome, TranscriptTurn } from '../types/agent';

export interface EvaluationResult {
  outcome: LeadOutcome;
  sentiment: 'positive' | 'negative' | 'neutral' | 'opt_out';
  answeredSlotsCount: number;
  isOptOut: boolean;
  isNotInterested: boolean;
  summary: string;
  nextAction: string;
}

const OPT_OUT_PATTERNS = [
  /don'?t call me again/i,
  /stop calling/i,
  /remove my number/i,
  /remove me from/i,
  /take me off/i,
  /do not call/i,
  /unsubscribe/i,
  /never call/i,
  /என்னை அழைக்காதீர்கள்/i,
  /தொடர்பு கொள்ள வேண்டாம்/i,
  /நம்பரை நீக்குங்கள்/i,
];

const NEGATIVE_PATTERNS = [
  /not interested/i,
  /don'?t need/i,
  /don'?t want/i,
  /no thanks/i,
  /wrong number/i,
  /not buying/i,
  /no requirement/i,
  /please leave me alone/i,
  /வேண்டாம்/i,
  /ஆர்வம் இல்லை/i,
  /தேவை இல்லை/i,
];

const POSITIVE_PATTERNS = [
  /interested/i,
  /looking to buy/i,
  /want to buy/i,
  /want to invest/i,
  /send details/i,
  /call me back/i,
  /schedule a visit/i,
  /view property/i,
  /2bhk/i,
  /3bhk/i,
  /villa/i,
  /apartment/i,
  /flat/i,
  /ஆமாம்/i,
  /வாங்க யோசனை/i,
  /முதலீடு/i,
];

export function checkIsOptOut(text: string): boolean {
  return OPT_OUT_PATTERNS.some((pattern) => pattern.test(text));
}

export function checkIsNotInterested(text: string): boolean {
  return NEGATIVE_PATTERNS.some((pattern) => pattern.test(text));
}

export function checkIsPositive(text: string): boolean {
  return POSITIVE_PATTERNS.some((pattern) => pattern.test(text));
}

/**
 * Deterministic qualification scoring engine per specifications:
 *
 * HOT:
 *  - Interested
 *  - + Budget given
 *  - + Timeline within 3 months
 *  - + At least 4 of 5 slots answered
 *
 * WARM:
 *  - Interested, but timeline is more than 3 months OR budget is unclear
 *  - (and at least 2 slots answered)
 *
 * COLD:
 *  - Not interested OR refuses OR fewer than 2 slots answered
 *
 * OPT_OUT:
 *  - Customer explicitly asks not to be called again
 */
export function evaluateCallOutcome(
  leadName: string,
  leadData: LeadData,
  transcript: TranscriptTurn[],
  callConnected: boolean = true
): EvaluationResult {
  // If call was never connected or cancelled immediately
  if (!callConnected) {
    return {
      outcome: 'NO_ANSWER',
      sentiment: 'neutral',
      answeredSlotsCount: 0,
      isOptOut: false,
      isNotInterested: false,
      summary: `${leadName} was called but did not answer or the connection timed out.`,
      nextAction: 'Retry outbound call during business hours.',
    };
  }

  // Combine user turns text for intent detection
  const userText = transcript
    .filter((t) => t.role === 'user')
    .map((t) => t.text)
    .join(' ');

  const isOptOut =
    checkIsOptOut(userText) ||
    leadData.notes?.toLowerCase().includes('opt_out') ||
    leadData.notes?.toLowerCase().includes('dnc') ||
    leadData.qualification_status === 'COLD' && checkIsOptOut(leadData.notes || '');

  if (isOptOut) {
    return {
      outcome: 'OPT_OUT',
      sentiment: 'opt_out',
      answeredSlotsCount: 0,
      isOptOut: true,
      isNotInterested: true,
      summary: `${leadName} requested to be removed from the calling list (Opt-Out / Do Not Call).`,
      nextAction: 'Permanently mark as DNC; suppress from all future call queues.',
    };
  }

  const isNotInterested =
    checkIsNotInterested(userText) ||
    leadData.interest.toLowerCase().includes('not interested') ||
    leadData.interest.toLowerCase().includes('வேண்டாம்') ||
    leadData.interest.toLowerCase().includes('ஆர்வம் இல்லை');

  // Count answered qualification slots (5 core slots)
  let answeredSlots = 0;
  if (leadData.interest && !isNotInterested) answeredSlots++;
  if (leadData.buyer_type) answeredSlots++;
  if (leadData.property_type) answeredSlots++;
  if (leadData.budget) answeredSlots++;
  if (leadData.timeline) answeredSlots++;

  // Location can also reinforce data
  const hasBudget = Boolean(leadData.budget && leadData.budget.trim().length > 1);

  // Check timeline <= 3 months
  const tl = (leadData.timeline || '').toLowerCase();
  const isTimelineWithin3Months =
    tl.includes('immediate') ||
    tl.includes('30') ||
    tl.includes('1 month') ||
    tl.includes('2 month') ||
    tl.includes('3 month') ||
    tl.includes('1-3') ||
    tl.includes('2-3') ||
    tl.includes('soon') ||
    tl.includes('now') ||
    tl.includes('உடனே') ||
    tl.includes('1 மாச') ||
    tl.includes('2 மாச') ||
    tl.includes('3 மாச');

  // Determine sentiment
  let sentiment: 'positive' | 'negative' | 'neutral' | 'opt_out' = 'neutral';
  if (isNotInterested) {
    sentiment = 'negative';
  } else if (checkIsPositive(userText) || answeredSlots >= 2) {
    sentiment = 'positive';
  }

  // Deterministic evaluation logic
  let outcome: LeadOutcome = 'COLD';
  let nextAction = '';

  if (isNotInterested) {
    outcome = 'COLD';
    nextAction = 'Archive lead or enroll into inactive nurture list.';
  } else if (
    sentiment === 'positive' &&
    hasBudget &&
    isTimelineWithin3Months &&
    answeredSlots >= 4
  ) {
    outcome = 'HOT';
    nextAction = 'Immediate Senior Sales Agent callback with curated project inventory.';
  } else if (
    (sentiment === 'positive' || answeredSlots >= 2) &&
    (!isTimelineWithin3Months || !hasBudget || answeredSlots >= 2)
  ) {
    outcome = 'WARM';
    nextAction = 'Follow-up via WhatsApp brochure & scheduled callback in 2-3 weeks.';
  } else {
    outcome = 'COLD';
    nextAction = 'Send automated quarterly market update newsletter.';
  }

  // Generate concise natural summary
  let summary = '';
  if (outcome === 'HOT') {
    summary = `${leadName} is actively looking to purchase ${
      leadData.property_type || 'a residential property'
    }${leadData.location ? ` in ${leadData.location}` : ''} with a verified budget of ${
      leadData.budget || 'specified range'
    }. Timeline: ${leadData.timeline || 'within 3 months'}. Highly responsive prospect.`;
  } else if (outcome === 'WARM') {
    summary = `${leadName} expressed interest in ${
      leadData.property_type || 'real estate opportunities'
    }${leadData.location ? ` in ${leadData.location}` : ''}. Budget: ${
      leadData.budget || 'Flexible / unfinalized'
    }. Timeline: ${leadData.timeline || '3+ months or flexible'}.`;
  } else {
    summary = `${leadName} was reached but did not have active property requirements at this time (${
      isNotInterested ? 'stated not interested' : `${answeredSlots}/5 slots provided`
    }).`;
  }

  return {
    outcome,
    sentiment,
    answeredSlotsCount: answeredSlots,
    isOptOut: false,
    isNotInterested,
    summary,
    nextAction,
  };
}
