import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { DashboardStatsView } from './components/DashboardStatsView';
import { LeadTable } from './components/LeadTable';
import { SimulatedCallScreen } from './components/SimulatedCallScreen';
import { CallHistoryView } from './components/CallHistoryView';
import { ApiUsageTab } from './components/ApiUsageTab';
import { ImportLeadsModal } from './components/ImportLeadsModal';
import { ExportModal } from './components/ExportModal';
import { TwilioConfigModal } from './components/TwilioConfigModal';
import { EditLeadModal } from './components/EditLeadModal';



import {
  getLeads,
  updateLead,
  deleteLead,
  importLeads as storeImportLeads,
  getCalls,
  saveCall,
  clearAllCalls,
  computeDashboardStats,
} from './storage';
import { evaluateCallOutcome } from './utils/scoring';
import { exportResultsToCsv, ParsedCsvRow } from './utils/csv';
import { LiveAudioPlayer, LiveMicRecorder, getAvailableMicrophones } from './utils/audio';

import {
  LeadRecord,
  CallRecord,
  LeadData,
  CallStatus,
  TranscriptTurn,
  AudioInputDeviceInfo,
  LeadQualificationStatus,
  ApiUsageData,
  LeadOutcome,
} from './types/agent';

import {
  LayoutDashboard,
  Users,
  PhoneCall,
  History,
  Zap,
  AlertTriangle,
} from 'lucide-react';

const INITIAL_LEAD_DATA: LeadData = {
  interest: '',
  buyer_type: '',
  property_type: '',
  budget: '',
  location: '',
  timeline: '',
  qualification_status: 'PENDING',
  stage_reached: 1,
  notes: '',
};

type AppTab = 'dashboard' | 'leads' | 'active-call' | 'history' | 'usage';

export default function App() {
  // Tab Navigation
  const [activeTab, setActiveTab] = useState<AppTab>('dashboard');
  const [leadTableFilter, setLeadTableFilter] = useState<string>('ALL');

  // Leads & Calls Data from Storage Layer
  const [leads, setLeads] = useState<LeadRecord[]>([]);
  const [calls, setCalls] = useState<CallRecord[]>([]);

  // Active Call Prospect
  const [activeLead, setActiveLead] = useState<LeadRecord | null>(null);
  const [lastOutcomeResult, setLastOutcomeResult] = useState<{
    outcome: LeadOutcome;
    summary: string;
    nextAction: string;
  } | null>(null);

  // Modals
  const [isImportOpen, setIsImportOpen] = useState<boolean>(false);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isTwilioConfigOpen, setIsTwilioConfigOpen] = useState<boolean>(false);
  const [editingLead, setEditingLead] = useState<LeadRecord | null>(null);
  const [optOutNotice, setOptOutNotice] = useState<string | null>(null);

  // Theme state: dark / light
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('lyka_theme') as 'dark' | 'light') || 'dark';
  });

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    localStorage.setItem('lyka_theme', next);
  };

  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.add('light-theme');
      document.body.classList.add('light-theme');
    } else {
      document.documentElement.classList.remove('light-theme');
      document.body.classList.remove('light-theme');
    }
  }, [theme]);

  // Calling Mode for active call screen: 'browser' | 'twilio'
  const [callScreenMode, setCallScreenMode] = useState<'browser' | 'twilio'>('browser');




  // Live Voice Call State (Preserved from working agent)
  const [callStatus, setCallStatus] = useState<CallStatus>('idle');
  const [genderVoice, setGenderVoice] = useState<'female' | 'male'>('female');
  const [selectedVoice, setSelectedVoice] = useState<string>('Kore');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('bilingual');
  const [selectedMicId, setSelectedMicId] = useState<string>('default');
  const [availableMics, setAvailableMics] = useState<AudioInputDeviceInfo[]>([
    { deviceId: 'default', label: 'Default Microphone', isBluetooth: false, isDefault: true },
  ]);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [isMicMuted, setIsMicMuted] = useState<boolean>(false);
  const [leadData, setLeadData] = useState<LeadData>(INITIAL_LEAD_DATA);
  const [turns, setTurns] = useState<TranscriptTurn[]>([]);
  const [isAgentSpeaking, setIsAgentSpeaking] = useState<boolean>(false);
  const [agentAudioEnergy, setAgentAudioEnergy] = useState<number>(0);
  const [micEnergy, setMicEnergy] = useState<number>(0);

  // API Usage metrics state
  const [apiUsageData, setApiUsageData] = useState<ApiUsageData | null>(null);
  const [isLoadingUsage, setIsLoadingUsage] = useState<boolean>(false);

  // Internal Refs
  const wsRef = useRef<WebSocket | null>(null);
  const audioPlayerRef = useRef<LiveAudioPlayer | null>(null);
  const micRecorderRef = useRef<LiveMicRecorder | null>(null);
  const timerRef = useRef<any>(null);
  const dialingTimerRef = useRef<any>(null);
  const callStartTimeRef = useRef<string>('');
  const currentAgentTurnIdRef = useRef<string | null>(null);
  const currentUserTurnIdRef = useRef<string | null>(null);

  // Load storage data on mount
  const refreshStorageData = useCallback(() => {
    const loadedLeads = getLeads();
    const loadedCalls = getCalls();
    setLeads(loadedLeads);
    setCalls(loadedCalls);
  }, []);

  useEffect(() => {
    refreshStorageData();
  }, [refreshStorageData]);

  // Compute live dashboard metrics
  const dashboardStats = computeDashboardStats(leads, calls);

  // Switch voice when gender changes (Kore = Female, Puck = Male)
  const handleGenderVoiceChange = (gender: 'female' | 'male') => {
    setGenderVoice(gender);
    setSelectedVoice(gender === 'female' ? 'Kore' : 'Puck');
  };

  // Enumerate audio input devices (default, bluetooth headset, etc.)
  const refreshMics = useCallback(async () => {
    const devices = await getAvailableMicrophones();
    setAvailableMics(devices);
  }, []);

  // Fetch real-time API usage and quota metrics
  const fetchApiUsage = useCallback(async () => {
    try {
      setIsLoadingUsage(true);
      const res = await fetch('/api/usage');
      if (res.ok) {
        const data = await res.json();
        setApiUsageData(data);
      }
    } catch (err) {
      console.error('[API Usage] Error fetching metrics:', err);
    } finally {
      setIsLoadingUsage(false);
    }
  }, []);

  useEffect(() => {
    refreshMics();
    fetchApiUsage();

    const interval = setInterval(fetchApiUsage, 20000);

    if (navigator.mediaDevices && navigator.mediaDevices.addEventListener) {
      navigator.mediaDevices.addEventListener('devicechange', refreshMics);
      return () => {
        clearInterval(interval);
        navigator.mediaDevices.removeEventListener('devicechange', refreshMics);
      };
    }

    return () => clearInterval(interval);
  }, [refreshMics, fetchApiUsage]);

  // Handle live switching of microphone input
  const handleMicChange = async (newDeviceId: string) => {
    setSelectedMicId(newDeviceId);
    if (micRecorderRef.current) {
      await micRecorderRef.current.switchDevice(newDeviceId);
    }
  };

  // Call duration timer
  useEffect(() => {
    if (
      callStatus === 'connected' ||
      callStatus === 'speaking' ||
      callStatus === 'listening' ||
      callStatus === 'interrupted'
    ) {
      timerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [callStatus]);

  // Audio player initialization
  useEffect(() => {
    audioPlayerRef.current = new LiveAudioPlayer(
      (playing) => {
        setIsAgentSpeaking(playing);
        if (playing) {
          setCallStatus('speaking');
        } else {
          setCallStatus((curr) => (curr === 'speaking' ? 'listening' : curr));
        }
      },
      (energy) => {
        setAgentAudioEnergy(energy);
      }
    );

    return () => {
      audioPlayerRef.current?.close();
    };
  }, []);

  // -------------------------------------------------------------
  // SIMULATED OUTBOUND CALL PIPELINE (Reusing Gemini Live Engine)
  // -------------------------------------------------------------
  const startSimulatedCallForLead = (targetLead: LeadRecord, mode: 'browser' | 'twilio' = 'browser') => {
    // 1. Compliance Safety Check: Opt-Out / DNC
    if (targetLead.isOptedOut || targetLead.outcome === 'OPT_OUT') {
      setOptOutNotice(
        `Call blocked by Compliance: "${targetLead.name}" has permanently opted out (Do Not Call).`
      );
      return;
    }

    // Reset previous call session state
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {}
      wsRef.current = null;
    }
    micRecorderRef.current?.stop();
    audioPlayerRef.current?.stopAndClear();

    setActiveLead(targetLead);
    setCallScreenMode(mode);
    setLastOutcomeResult(null);
    setLeadData(INITIAL_LEAD_DATA);
    setTurns([]);
    setCallDuration(0);
    currentAgentTurnIdRef.current = null;
    currentUserTurnIdRef.current = null;
    callStartTimeRef.current = new Date().toISOString();

    // Switch to active call tab
    setActiveTab('active-call');

    if (mode === 'browser') {
      // Simulate outbound ringing delay (1.5 seconds)
      setCallStatus('connecting');
      updateLead(targetLead.id, { callStatus: 'CALLING' });
      refreshStorageData();

      if (dialingTimerRef.current) clearTimeout(dialingTimerRef.current);

      dialingTimerRef.current = setTimeout(() => {
        connectVoiceSession(targetLead);
      }, 1500);
    } else {
      // Twilio mode: Ready for Twilio dialing
      setCallStatus('idle');
    }
  };

  const connectVoiceSession = async (targetLead: LeadRecord) => {
    await refreshMics();

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/live-ws`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log(`[WebSocket] Connected for lead: ${targetLead.name} (${selectedVoice}, ${selectedLanguage})`);
      ws.send(
        JSON.stringify({
          type: 'start',
          voice: selectedVoice,
          language: selectedLanguage,
          leadName: targetLead.name,
        })
      );
      setTimeout(fetchApiUsage, 1000);
    };

    ws.onmessage = async (event) => {
      try {
        const msg = JSON.parse(event.data);

        // 1. Session Ready from Gemini Live -> Prospect Answers
        if (msg.type === 'ready') {
          setCallStatus('connected');
          updateLead(targetLead.id, { callStatus: 'CONNECTED' });
          refreshStorageData();

          // Initialize microphone recorder
          micRecorderRef.current = new LiveMicRecorder(
            (base64Chunk) => {
              if (ws.readyState === WebSocket.OPEN && !isMicMuted) {
                ws.send(JSON.stringify({ type: 'audio', data: base64Chunk }));
              }
            },
            (energy) => {
              setMicEnergy(energy);
            },
            (speechText, isFinal) => {
              const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

              setTurns((prev) => {
                if (currentUserTurnIdRef.current) {
                  const turnId = currentUserTurnIdRef.current;
                  return prev.map((t) => (t.id === turnId ? { ...t, text: speechText, isStreaming: !isFinal } : t));
                } else {
                  const newId = `user-${Date.now()}`;
                  currentUserTurnIdRef.current = newId;
                  return [
                    ...prev,
                    {
                      id: newId,
                      role: 'user',
                      text: speechText,
                      timestamp,
                      isStreaming: !isFinal,
                    },
                  ];
                }
              });

              if (isFinal) {
                currentUserTurnIdRef.current = null;
                if (ws.readyState === WebSocket.OPEN) {
                  ws.send(JSON.stringify({ type: 'user_speech_transcript', text: speechText }));
                }

                // Check immediate opt out phrase from user speech
                const lower = speechText.toLowerCase();
                if (lower.includes("don't call me again") || lower.includes('remove my number') || lower.includes('stop calling')) {
                  setTimeout(() => handleEndCall('opt_out'), 1200);
                } else if (lower.includes('not interested') || lower.includes("don't need")) {
                  setTimeout(() => handleEndCall('not_interested'), 1200);
                }
              }
            },
            selectedLanguage,
            selectedMicId
          );

          await micRecorderRef.current.start(selectedMicId);
          refreshMics();
        }

        // 2. Audio Chunks from Gemini Live
        if (msg.type === 'audio' && msg.data) {
          audioPlayerRef.current?.playChunk(msg.data);
        }

        // 3. Streaming Transcript
        if (msg.type === 'transcript') {
          const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

          if (msg.role === 'agent') {
            setTurns((prev) => {
              if (currentAgentTurnIdRef.current) {
                const turnId = currentAgentTurnIdRef.current;
                return prev.map((t) => (t.id === turnId ? { ...t, text: t.text + msg.text } : t));
              } else {
                const newId = `agent-${Date.now()}`;
                currentAgentTurnIdRef.current = newId;
                return [
                  ...prev,
                  {
                    id: newId,
                    role: 'agent',
                    text: msg.text,
                    timestamp,
                  },
                ];
              }
            });
          } else if (msg.role === 'user') {
            setTurns((prev) => {
              if (currentUserTurnIdRef.current) {
                const turnId = currentUserTurnIdRef.current;
                return prev.map((t) => (t.id === turnId ? { ...t, text: t.text + msg.text } : t));
              } else {
                const newId = `user-${Date.now()}`;
                currentUserTurnIdRef.current = newId;
                return [
                  ...prev,
                  {
                    id: newId,
                    role: 'user',
                    text: msg.text,
                    timestamp,
                  },
                ];
              }
            });
          }
        }

        // 4. Interrupted
        if (msg.type === 'interrupted') {
          audioPlayerRef.current?.stopAndClear();
          setCallStatus('interrupted');
          if (currentAgentTurnIdRef.current) {
            setTurns((prev) =>
              prev.map((t) => (t.id === currentAgentTurnIdRef.current ? { ...t, interrupted: true } : t))
            );
          }
          currentAgentTurnIdRef.current = null;
        }

        // 5. Turn Complete
        if (msg.type === 'turn_complete') {
          currentAgentTurnIdRef.current = null;
          currentUserTurnIdRef.current = null;
          setCallStatus((prev) => (prev !== 'idle' && prev !== 'ended' ? 'listening' : prev));
          fetchApiUsage();
        }

        // 6. Lead Update from Structured toolCall
        if (msg.type === 'lead_update' && msg.lead) {
          setLeadData((prev) => {
            const updated: LeadData = {
              interest: msg.lead.interest || prev.interest,
              buyer_type: msg.lead.buyer_type || prev.buyer_type,
              property_type: msg.lead.property_type || prev.property_type,
              budget: msg.lead.budget || prev.budget,
              location: msg.lead.location || prev.location,
              timeline: msg.lead.timeline || prev.timeline,
              stage_reached: msg.lead.stage_reached || prev.stage_reached,
              notes: msg.lead.notes || prev.notes,
              qualification_status: (msg.lead.qualification_status as LeadQualificationStatus) || prev.qualification_status,
              updated_at: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            };
            return updated;
          });

          // If tool call explicitly flagged opt-out or not interested
          if (msg.lead.qualification_status === 'OPT_OUT') {
            setTimeout(() => handleEndCall('opt_out'), 1000);
          }
        }

        // 7. Error handling
        if (msg.type === 'error') {
          console.error('[WebSocket Error]:', msg.message);
          setCallStatus('error');
          setTurns((prev) => [
            ...prev,
            {
              id: `sys-${Date.now()}`,
              role: 'system',
              text: `Notice: ${msg.message}`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            },
          ]);
        }
      } catch (err) {
        console.error('[WebSocket] Parsing error:', err);
      }
    };

    ws.onerror = (err) => {
      console.error('[WebSocket] Connection error:', err);
      setCallStatus('error');
    };

    ws.onclose = () => {
      micRecorderRef.current?.stop();
      audioPlayerRef.current?.stopAndClear();
      setCallStatus((prev) => (prev !== 'error' ? 'ended' : 'error'));
      fetchApiUsage();
    };
  };

  // -------------------------------------------------------------
  // END CALL & SAVE OUTCOME
  // -------------------------------------------------------------
  const handleEndCall = (reason?: string) => {
    if (dialingTimerRef.current) {
      clearTimeout(dialingTimerRef.current);
      dialingTimerRef.current = null;
    }

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'end' }));
      wsRef.current.close();
    }
    micRecorderRef.current?.stop();
    audioPlayerRef.current?.stopAndClear();

    const wasConnected = callStatus !== 'connecting' && callStatus !== 'idle';
    setCallStatus('ended');
    currentAgentTurnIdRef.current = null;
    currentUserTurnIdRef.current = null;

    if (!activeLead) return;

    // Run deterministic qualification & summary evaluation
    let evaluation = evaluateCallOutcome(activeLead.name, leadData, turns, wasConnected);

    if (reason === 'opt_out') {
      evaluation.outcome = 'OPT_OUT';
      evaluation.isOptOut = true;
      evaluation.sentiment = 'opt_out';
      evaluation.summary = `${activeLead.name} requested to be removed from the calling list (Opt-Out / Do Not Call).`;
      evaluation.nextAction = 'Permanently mark as DNC; suppress from all future call queues.';
    } else if (reason === 'not_interested') {
      evaluation.outcome = 'COLD';
      evaluation.sentiment = 'negative';
      evaluation.summary = `${activeLead.name} stated not interested in real estate services at this time.`;
      evaluation.nextAction = 'Archive lead or enroll into inactive nurture list.';
    }

    setLastOutcomeResult({
      outcome: evaluation.outcome,
      summary: evaluation.summary,
      nextAction: evaluation.nextAction,
    });

    // 1. Update Lead Record in Storage
    const updatedLeadRecord: Partial<LeadRecord> = {
      callStatus: wasConnected ? 'COMPLETED' : 'NO_ANSWER',
      outcome: evaluation.outcome,
      interest: leadData.interest || (evaluation.outcome === 'HOT' || evaluation.outcome === 'WARM' ? 'Interested' : 'Not interested'),
      buyerType: leadData.buyer_type,
      propertyType: leadData.property_type,
      budget: leadData.budget,
      location: leadData.location,
      timeline: leadData.timeline,
      lastCalledAt: new Date().toISOString(),
      isOptedOut: evaluation.isOptOut,
      notes: evaluation.summary,
    };
    updateLead(activeLead.id, updatedLeadRecord);

    // 2. Save Complete Call Record in Storage
    const callRecord: CallRecord = {
      callId: `call-${Date.now()}`,
      leadId: activeLead.id,
      leadName: activeLead.name,
      leadPhone: activeLead.phone,
      startedAt: callStartTimeRef.current || new Date().toISOString(),
      endedAt: new Date().toISOString(),
      duration: callDuration,
      callStatus: wasConnected ? 'COMPLETED' : 'NO_ANSWER',
      interest: leadData.interest,
      buyerType: leadData.buyer_type,
      propertyType: leadData.property_type,
      budget: leadData.budget,
      location: leadData.location,
      timeline: leadData.timeline,
      sentiment: evaluation.sentiment,
      outcome: evaluation.outcome,
      summary: evaluation.summary,
      transcript: [...turns],
      nextAction: evaluation.nextAction,
    };
    saveCall(callRecord);

    // Refresh UI state
    refreshStorageData();
    fetchApiUsage();
  };

  const handleToggleMic = () => {
    setIsMicMuted((prev) => !prev);
  };

  const handleSendText = (text: string) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setTurns((prev) => [
        ...prev,
        {
          id: `user-${Date.now()}`,
          role: 'user',
          text,
          timestamp,
        },
      ]);

      if (audioPlayerRef.current?.isPlaying) {
        audioPlayerRef.current.stopAndClear();
        setCallStatus('interrupted');
      }

      currentAgentTurnIdRef.current = null;
      wsRef.current.send(JSON.stringify({ type: 'text', text }));

      // Quick sentiment triggers
      const lower = text.toLowerCase();
      if (lower.includes("don't call me again") || lower.includes('remove my number')) {
        setTimeout(() => handleEndCall('opt_out'), 1000);
      } else if (lower.includes('not interested')) {
        setTimeout(() => handleEndCall('not_interested'), 1000);
      }
    }
  };

  const handleTriggerBargeIn = () => {
    audioPlayerRef.current?.stopAndClear();
    setCallStatus('interrupted');
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'barge_in' }));
    }
  };

  const handleResetLead = () => {
    setLeadData(INITIAL_LEAD_DATA);
  };

  const handleApplyPreset = (preset: Partial<LeadData>) => {
    setLeadData((prev) => ({
      ...prev,
      ...preset,
    }));
  };

  // -------------------------------------------------------------
  // LEAD MANAGEMENT ACTIONS
  // -------------------------------------------------------------
  const handleDeleteLead = (id: string) => {
    deleteLead(id);
    refreshStorageData();
  };

  const handleImportCsvLeads = (newRows: ParsedCsvRow[]) => {
    const res = storeImportLeads(newRows);
    refreshStorageData();
    setActiveTab('leads');
  };

  const handleExportCsv = () => {
    exportResultsToCsv(leads, calls);
  };

  const handleClearHistory = () => {
    clearAllCalls();
    refreshStorageData();
  };

  const handleRealCallSaved = (realRecord: CallRecord) => {
    saveCall(realRecord);
    updateLead(realRecord.leadId, {
      callStatus: realRecord.callStatus,
      outcome: realRecord.outcome,
      lastCalledAt: realRecord.endedAt,
      notes: realRecord.summary,
      isOptedOut: realRecord.outcome === 'OPT_OUT',
    });
    refreshStorageData();
    fetchApiUsage();
  };

  const handleSaveEditedLead = (id: string, updates: Partial<LeadRecord>) => {
    updateLead(id, updates);
    refreshStorageData();
    if (activeLead && activeLead.id === id) {
      setActiveLead((prev) => (prev ? { ...prev, ...updates } : null));
    }
  };

  const navigateToLeadsWithFilter = (filterKey?: string) => {
    if (filterKey) setLeadTableFilter(filterKey);
    setActiveTab('leads');
  };

  const isCallActive =
    callStatus !== 'idle' && callStatus !== 'ended' && callStatus !== 'error';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Header */}
      <Header
        callStatus={callStatus}
        callDuration={callDuration}
        genderVoice={genderVoice}
        onGenderVoiceChange={handleGenderVoiceChange}
        selectedLanguage={selectedLanguage}
        onLanguageChange={(langId) => setSelectedLanguage(langId)}
        selectedMicId={selectedMicId}
        onMicChange={handleMicChange}
        availableMics={availableMics}
        onOpenExport={() => setIsExportOpen(true)}
        onOpenTwilio={() => setIsTwilioConfigOpen(true)}
        theme={theme}
        onToggleTheme={toggleTheme}
      />

      {/* Compliance / Opt-Out Notice Toast */}
      {optOutNotice && (
        <div className="max-w-5xl mx-auto w-full px-4 pt-3">
          <div className="flex items-center justify-between p-3 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{optOutNotice}</span>
            </div>
            <button
              onClick={() => setOptOutNotice(null)}
              className="text-rose-400 hover:text-white text-xs underline cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Main Workspace */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-4 sm:p-5 space-y-4">
        {/* Main Tab Navigation */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 flex-wrap gap-2">
          <div className="flex items-center flex-wrap gap-1.5">
            {/* Tab 1: Dashboard Overview */}
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'dashboard'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>Dashboard</span>
            </button>

            {/* Tab 2: Leads Table */}
            <button
              onClick={() => setActiveTab('leads')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'leads'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Leads ({leads.length})</span>
            </button>

            {/* Tab 3: Active Call Screen */}
            <button
              onClick={() => {
                if (!activeLead && leads.length > 0) {
                  setActiveLead(leads[0]);
                }
                setActiveTab('active-call');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'active-call'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
              }`}
            >
              <PhoneCall className={`w-3.5 h-3.5 ${isCallActive ? 'text-emerald-400 animate-pulse' : ''}`} />
              <span>
                {isCallActive ? 'Active Call 📞' : 'Call Screen'}
              </span>
            </button>

            {/* Tab 4: Call History */}
            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>History ({calls.length})</span>
            </button>

            {/* Tab 5: API Usage */}
            <button
              onClick={() => {
                setActiveTab('usage');
                fetchApiUsage();
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'usage'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>API Quota</span>
            </button>
          </div>

          {/* Quick Stats Pill */}
          <div
            onClick={() => setActiveTab('dashboard')}
            className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono cursor-pointer hover:border-slate-700 transition-colors"
          >
            <span className="text-slate-400">Answer Rate:</span>
            <strong className="text-emerald-400">{dashboardStats.answerRate}%</strong>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400">HOT:</span>
            <strong className="text-rose-400">{dashboardStats.hot}</strong>
          </div>
        </div>

        {/* ---------------- Tab 1: Dashboard Overview ---------------- */}
        {activeTab === 'dashboard' && (
          <DashboardStatsView
            stats={dashboardStats}
            onNavigateToLeads={navigateToLeadsWithFilter}
            onOpenImport={() => setIsImportOpen(true)}
            onExportCsv={handleExportCsv}
          />
        )}

        {/* ---------------- Tab 2: Leads Management ---------------- */}
        {activeTab === 'leads' && (
          <LeadTable
            leads={leads}
            onStartCall={startSimulatedCallForLead}
            onEditLead={(lead) => setEditingLead(lead)}
            onDeleteLead={handleDeleteLead}
            onOpenImport={() => setIsImportOpen(true)}
            onExportCsv={handleExportCsv}
            activeFilter={leadTableFilter}
            onFilterChange={(f) => setLeadTableFilter(f)}
          />
        )}

        {/* ---------------- Tab 3: Active Simulated Call Screen ---------------- */}
        {activeTab === 'active-call' && (
          activeLead ? (
            <SimulatedCallScreen
              lead={activeLead}
              leadData={leadData}
              callStatus={callStatus}
              callDuration={callDuration}
              turns={turns}
              isAgentSpeaking={isAgentSpeaking}
              agentAudioEnergy={agentAudioEnergy}
              micEnergy={micEnergy}
              isMicMuted={isMicMuted}
              selectedLanguage={selectedLanguage}
              onToggleMic={handleToggleMic}
              onStartCall={() => startSimulatedCallForLead(activeLead)}
              onEndCall={(reason) => handleEndCall(reason)}
              onSendText={handleSendText}
              onTriggerBargeIn={handleTriggerBargeIn}
              onResetLead={handleResetLead}
              onApplyPreset={handleApplyPreset}
              onReturnToDashboard={() => setActiveTab('leads')}
              lastOutcomeResult={lastOutcomeResult}
              onOpenTwilioConfig={() => setIsTwilioConfigOpen(true)}
              onRealCallSaved={handleRealCallSaved}
              initialCallMode={callScreenMode}
            />
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center text-slate-500 space-y-3">
              <PhoneCall className="w-10 h-10 mx-auto text-slate-600 opacity-60" />
              <h3 className="text-sm font-semibold text-slate-300">
                No Lead Selected for Calling
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Select a lead from your Leads Table and click the [ CALL ] button to begin a simulated outbound call.
              </p>
              <button
                onClick={() => setActiveTab('leads')}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors cursor-pointer"
              >
                Go to Leads Table →
              </button>
            </div>
          )
        )}

        {/* ---------------- Tab 4: Call History ---------------- */}
        {activeTab === 'history' && (
          <CallHistoryView
            calls={calls}
            onClearHistory={handleClearHistory}
          />
        )}

        {/* ---------------- Tab 5: API Usage & Quota ---------------- */}
        {activeTab === 'usage' && (
          <ApiUsageTab
            usageData={apiUsageData}
            onRefresh={fetchApiUsage}
            isLoading={isLoadingUsage}
          />
        )}
      </main>

      {/* CSV Import Modal */}
      <ImportLeadsModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onImport={handleImportCsvLeads}
      />

      {/* Export / GitHub Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />

      {/* Twilio Configuration Modal */}
      <TwilioConfigModal
        isOpen={isTwilioConfigOpen}
        onClose={() => setIsTwilioConfigOpen(false)}
        onConfigSaved={refreshStorageData}
      />

      {/* Edit Lead Details Modal */}
      <EditLeadModal
        isOpen={Boolean(editingLead)}
        lead={editingLead}
        onClose={() => setEditingLead(null)}
        onSaveLead={handleSaveEditedLead}
      />
    </div>
  );
}

