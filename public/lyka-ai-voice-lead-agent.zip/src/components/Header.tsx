import React from 'react';
import {
  Building2,
  Clock,
  Mic,
  Bluetooth,
  ChevronDown,
  Volume2,
  Download,
  Github,
  Phone,
  Sun,
  Moon,
} from 'lucide-react';
import { CallStatus, AudioInputDeviceInfo } from '../types/agent';

interface HeaderProps {
  callStatus: CallStatus;
  callDuration: number;
  genderVoice: 'female' | 'male';
  onGenderVoiceChange: (gender: 'female' | 'male') => void;
  selectedLanguage: string;
  onLanguageChange: (langId: string) => void;
  selectedMicId: string;
  onMicChange: (deviceId: string) => void;
  availableMics: AudioInputDeviceInfo[];
  onOpenExport: () => void;
  onOpenTwilio?: () => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  callStatus,
  callDuration,
  genderVoice,
  onGenderVoiceChange,
  selectedLanguage,
  onLanguageChange,
  selectedMicId,
  onMicChange,
  availableMics,
  onOpenExport,
  onOpenTwilio,
  theme = 'dark',
  onToggleTheme,
}) => {
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  const currentMic = availableMics.find((m) => m.deviceId === selectedMicId);
  const isCallActive = callStatus !== 'idle' && callStatus !== 'ended' && callStatus !== 'error';

  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur px-4 py-3 sticky top-0 z-40">
      <div className="max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
            <Building2 className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-sm font-semibold text-slate-100 leading-tight">
              Lyka Realty
            </h1>
            <p className="text-[11px] text-slate-400">Voice Assistant</p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Active Call Timer */}
          {isCallActive && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-[11px]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>{formatTime(callDuration)}</span>
            </div>
          )}

          {/* Simple Voice Gender Toggle: Female / Male */}
          <div className="flex items-center bg-slate-800/80 rounded-lg p-0.5 border border-slate-700">
            <button
              onClick={() => onGenderVoiceChange('female')}
              disabled={isCallActive}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                genderVoice === 'female'
                  ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              👩 Female
            </button>
            <button
              onClick={() => onGenderVoiceChange('male')}
              disabled={isCallActive}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                genderVoice === 'male'
                  ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              👨 Male
            </button>
          </div>

          {/* Simple Language Selection */}
          <div className="flex items-center bg-slate-800/80 rounded-lg p-0.5 border border-slate-700">
            <button
              onClick={() => onLanguageChange('bilingual')}
              disabled={isCallActive}
              className={`px-2 py-1 rounded-md transition-all cursor-pointer ${
                selectedLanguage === 'bilingual'
                  ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              🌐 Auto
            </button>
            <button
              onClick={() => onLanguageChange('english')}
              disabled={isCallActive}
              className={`px-2 py-1 rounded-md transition-all cursor-pointer ${
                selectedLanguage === 'english'
                  ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              onClick={() => onLanguageChange('tamil')}
              disabled={isCallActive}
              className={`px-2 py-1 rounded-md transition-all cursor-pointer ${
                selectedLanguage === 'tamil'
                  ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              தமிழ்
            </button>
          </div>

          {/* Simple Mic Device Selector */}
          <div className="relative inline-block">
            <div className="absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
              {currentMic?.isBluetooth ? (
                <Bluetooth className="w-3.5 h-3.5 text-sky-400" />
              ) : (
                <Mic className="w-3.5 h-3.5 text-slate-400" />
              )}
            </div>
            <select
              value={selectedMicId}
              onChange={(e) => onMicChange(e.target.value)}
              title="Select Microphone (Default or Bluetooth)"
              className="appearance-none text-xs bg-slate-800 hover:bg-slate-750 text-slate-200 pl-7 pr-6 py-1.5 rounded-lg border border-slate-700 focus:outline-none focus:border-cyan-500 cursor-pointer max-w-[150px] truncate"
            >
              {availableMics.map((mic) => (
                <option key={mic.deviceId} value={mic.deviceId} className="bg-slate-900 text-slate-200">
                  {mic.isBluetooth ? '🎧 ' : '🎤 '}
                  {mic.label}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3 h-3 text-slate-400 absolute right-1.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Download ZIP / Push GitHub Button */}
          <button
            onClick={onOpenExport}
            title="Download Project (.ZIP) or Push to GitHub"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 hover:border-slate-600 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Export / GitHub</span>
          </button>

          {/* Twilio Outbound Real Call Setup */}
          {onOpenTwilio && (
            <button
              onClick={onOpenTwilio}
              title="Configure Twilio Real Phone Calling & Webhook URL"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 transition-colors cursor-pointer"
            >
              <Phone className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden sm:inline">Twilio Real Call</span>
            </button>
          )}

          {/* Dark / Light Theme Toggle */}
          {onToggleTheme && (
            <button
              onClick={onToggleTheme}
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 hover:border-slate-600 transition-colors cursor-pointer"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden md:inline">Light</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-sky-400" />
                  <span className="hidden md:inline">Dark</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
