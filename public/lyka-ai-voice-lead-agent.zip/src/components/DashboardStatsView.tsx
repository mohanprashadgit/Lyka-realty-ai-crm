import React from 'react';
import {
  Users,
  PhoneCall,
  PhoneForwarded,
  PhoneOff,
  ThumbsUp,
  ThumbsDown,
  Flame,
  SunMedium,
  Snowflake,
  ShieldBan,
  TrendingUp,
  Award,
  CheckCircle,
  FileSpreadsheet,
  Upload,
  ArrowRight,
} from 'lucide-react';
import { DashboardStats } from '../types/agent';

interface DashboardStatsViewProps {
  stats: DashboardStats;
  onNavigateToLeads: (filter?: string) => void;
  onOpenImport: () => void;
  onExportCsv: () => void;
}

export const DashboardStatsView: React.FC<DashboardStatsViewProps> = ({
  stats,
  onNavigateToLeads,
  onOpenImport,
  onExportCsv,
}) => {
  return (
    <div className="space-y-4">
      {/* Top Action Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            <span>Lyka AI Real Estate Cold-Calling Dashboard</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time conversion metrics calculated from active and completed simulated calls
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenImport}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 transition-colors cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-amber-400" />
            <span>Import Leads</span>
          </button>
          <button
            onClick={onExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => onNavigateToLeads('NOT_CALLED')}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/15 transition-all cursor-pointer"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>View Uncalled Leads</span>
          </button>
        </div>
      </div>

      {/* 4 Core Conversion Rates */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Answer Rate */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Answer Rate</span>
            <PhoneForwarded className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-emerald-400">
              {stats.answerRate}%
            </span>
            <span className="text-[11px] text-slate-500 font-mono">
              {stats.callsConnected}/{stats.callsMade || 0}
            </span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, stats.answerRate)}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400">Connected vs. Total calls made</p>
        </div>

        {/* Interested Rate */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Interest Rate</span>
            <ThumbsUp className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-cyan-400">
              {stats.interestedRate}%
            </span>
            <span className="text-[11px] text-slate-500 font-mono">
              {stats.interested}/{stats.callsConnected || 0}
            </span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-cyan-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, stats.interestedRate)}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400">Positive interest from connected calls</p>
        </div>

        {/* Qualification Rate */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Qualification Rate</span>
            <Award className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-amber-400">
              {stats.qualificationRate}%
            </span>
            <span className="text-[11px] text-slate-500 font-mono">
              {stats.hot + stats.warm}/{stats.callsConnected || 0}
            </span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-amber-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, stats.qualificationRate)}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400">HOT + WARM qualified leads</p>
        </div>

        {/* Hot Lead Rate */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Hot Lead Rate</span>
            <Flame className="w-4 h-4 text-rose-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-rose-400">
              {stats.hotLeadRate}%
            </span>
            <span className="text-[11px] text-slate-500 font-mono">
              {stats.hot}/{stats.callsConnected || 0}
            </span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-rose-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, stats.hotLeadRate)}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400">Immediate buyers (&lt;3 months + budget)</p>
        </div>
      </div>

      {/* 10 Operational Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {/* Total Leads */}
        <div
          onClick={() => onNavigateToLeads('ALL')}
          className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 rounded-xl p-3.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Total Leads</span>
            <Users className="w-3.5 h-3.5" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-100">{stats.totalLeads}</div>
          <span className="text-[10px] text-slate-500">In database</span>
        </div>

        {/* Calls Made */}
        <div
          onClick={() => onNavigateToLeads('CALLED')}
          className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 rounded-xl p-3.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Calls Made</span>
            <PhoneCall className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div className="text-xl font-bold font-mono text-sky-400">{stats.callsMade}</div>
          <span className="text-[10px] text-slate-500">Outbound attempts</span>
        </div>

        {/* Calls Connected */}
        <div
          onClick={() => onNavigateToLeads('CONNECTED')}
          className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 rounded-xl p-3.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Connected</span>
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-400">{stats.callsConnected}</div>
          <span className="text-[10px] text-slate-500">Conversation started</span>
        </div>

        {/* No Answer */}
        <div
          onClick={() => onNavigateToLeads('NO_ANSWER')}
          className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 rounded-xl p-3.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>No Answer</span>
            <PhoneOff className="w-3.5 h-3.5 text-slate-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-300">{stats.noAnswer}</div>
          <span className="text-[10px] text-slate-500">Ringing timeout</span>
        </div>

        {/* Interested */}
        <div
          onClick={() => onNavigateToLeads('INTERESTED')}
          className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 rounded-xl p-3.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Interested</span>
            <ThumbsUp className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-xl font-bold font-mono text-cyan-400">{stats.interested}</div>
          <span className="text-[10px] text-slate-500">Positive responses</span>
        </div>

        {/* Not Interested */}
        <div
          onClick={() => onNavigateToLeads('NOT_INTERESTED')}
          className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 rounded-xl p-3.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Not Interested</span>
            <ThumbsDown className="w-3.5 h-3.5 text-slate-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-300">{stats.notInterested}</div>
          <span className="text-[10px] text-slate-500">Declined purchase</span>
        </div>

        {/* HOT */}
        <div
          onClick={() => onNavigateToLeads('HOT')}
          className="bg-emerald-950/20 hover:bg-emerald-950/30 border border-emerald-500/30 rounded-xl p-3.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-emerald-400 text-xs mb-1">
            <span>HOT Leads</span>
            <Flame className="w-3.5 h-3.5" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-400">{stats.hot}</div>
          <span className="text-[10px] text-emerald-300/70">&lt; 3 mo + Budget</span>
        </div>

        {/* WARM */}
        <div
          onClick={() => onNavigateToLeads('WARM')}
          className="bg-amber-950/20 hover:bg-amber-950/30 border border-amber-500/30 rounded-xl p-3.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-amber-400 text-xs mb-1">
            <span>WARM Leads</span>
            <SunMedium className="w-3.5 h-3.5" />
          </div>
          <div className="text-xl font-bold font-mono text-amber-400">{stats.warm}</div>
          <span className="text-[10px] text-amber-300/70">3-6 mo or flexible</span>
        </div>

        {/* COLD */}
        <div
          onClick={() => onNavigateToLeads('COLD')}
          className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 rounded-xl p-3.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>COLD Leads</span>
            <Snowflake className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-300">{stats.cold}</div>
          <span className="text-[10px] text-slate-500">Unresponsive / &lt;2 slots</span>
        </div>

        {/* OPT-OUT */}
        <div
          onClick={() => onNavigateToLeads('OPT_OUT')}
          className="bg-rose-950/20 hover:bg-rose-950/30 border border-rose-500/30 rounded-xl p-3.5 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-rose-400 text-xs mb-1">
            <span>OPT-OUT (DNC)</span>
            <ShieldBan className="w-3.5 h-3.5" />
          </div>
          <div className="text-xl font-bold font-mono text-rose-400">{stats.optOut}</div>
          <span className="text-[10px] text-rose-300/70">Do Not Call enforced</span>
        </div>
      </div>
    </div>
  );
};
