import { CallRecord, DashboardStats, LeadRecord } from '../types/agent';

const CALLS_STORAGE_KEY = 'lyka_realty_calls_v1';

export function getCalls(): CallRecord[] {
  try {
    const raw = localStorage.getItem(CALLS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('[Storage] Error reading calls:', err);
    return [];
  }
}

export function saveCall(call: CallRecord): void {
  try {
    const current = getCalls();
    const updated = [call, ...current.filter((c) => c.callId !== call.callId)];
    localStorage.setItem(CALLS_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('[Storage] Error saving call:', err);
  }
}

export function updateCall(callId: string, updates: Partial<CallRecord>): void {
  try {
    const current = getCalls();
    const index = current.findIndex((c) => c.callId === callId);
    if (index === -1) return;
    current[index] = { ...current[index], ...updates };
    localStorage.setItem(CALLS_STORAGE_KEY, JSON.stringify(current));
  } catch (err) {
    console.error('[Storage] Error updating call:', err);
  }
}

export function getCallsByLeadId(leadId: string): CallRecord[] {
  const current = getCalls();
  return current.filter((c) => c.leadId === leadId);
}

export function getCallById(callId: string): CallRecord | null {
  const current = getCalls();
  return current.find((c) => c.callId === callId) || null;
}

export function clearAllCalls(): void {
  try {
    localStorage.removeItem(CALLS_STORAGE_KEY);
  } catch (err) {
    console.error('[Storage] Error clearing calls:', err);
  }
}

/**
 * Computes strictly derived metrics from stored leads and calls.
 * No hardcoded fake statistics.
 */
export function computeDashboardStats(
  leads: LeadRecord[],
  calls: CallRecord[]
): DashboardStats {
  const totalLeads = leads.length;
  const callsMade = calls.length;

  let callsConnected = 0;
  let noAnswer = 0;
  let interested = 0;
  let notInterested = 0;
  let hot = 0;
  let warm = 0;
  let cold = 0;
  let optOut = 0;

  // Track opt-outs from leads and calls
  leads.forEach((l) => {
    if (l.isOptedOut || l.outcome === 'OPT_OUT') {
      optOut++;
    }
  });

  calls.forEach((c) => {
    if (c.callStatus === 'CONNECTED' || c.callStatus === 'COMPLETED') {
      callsConnected++;
    } else if (c.callStatus === 'NO_ANSWER') {
      noAnswer++;
    }

    if (c.sentiment === 'positive' || c.outcome === 'HOT' || c.outcome === 'WARM') {
      interested++;
    } else if (c.sentiment === 'negative' || c.outcome === 'COLD' || c.outcome === 'OPT_OUT') {
      notInterested++;
    }

    if (c.outcome === 'HOT') hot++;
    else if (c.outcome === 'WARM') warm++;
    else if (c.outcome === 'COLD') cold++;
  });

  // Calculate percentage rates
  const answerRate = callsMade > 0 ? Math.round((callsConnected / callsMade) * 100) : 0;
  const interestedRate = callsConnected > 0 ? Math.round((interested / callsConnected) * 100) : 0;
  const qualificationRate = callsConnected > 0 ? Math.round(((hot + warm) / callsConnected) * 100) : 0;
  const hotLeadRate = callsConnected > 0 ? Math.round((hot / callsConnected) * 100) : 0;

  return {
    totalLeads,
    callsMade,
    callsConnected,
    noAnswer,
    interested,
    notInterested,
    hot,
    warm,
    cold,
    optOut,
    answerRate,
    interestedRate,
    qualificationRate,
    hotLeadRate,
  };
}
