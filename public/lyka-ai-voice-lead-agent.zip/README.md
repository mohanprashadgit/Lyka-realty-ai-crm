# Lyka Realty AI - Real Estate Voice Lead Agent 🎙️🏡

An ultra-natural, human-like bilingual (English & தமிழ்) real estate voice calling agent powered by **Google Gemini Live Native Audio** (`gemini-3.8-live`) with **Real Outbound PSTN Phone Calling via Twilio Voice**.

Lyka qualifies real estate prospects across a 5-stage qualification workflow, detects genuine user interruptions (barge-in), transcribes conversations in real time, and logs structured lead attributes directly into a CRM.

---

## 🌟 Key Features

- **Real Outbound Mobile Phone Calling (Twilio Voice)**:
  - Dials real mobile phone numbers via the Twilio PSTN network.
  - Bidirectional Twilio Media Streams (`/api/twilio/media`) converting telephone G.711 mu-law (8kHz) to/from Gemini Live linear PCM.
  - Interruption/barge-in support: when caller speaks, queued audio on the phone cuts off immediately.
- **Simulated Browser Voice Testing (Web Audio API)**:
  - 16,000 Hz linear PCM microphone input with echo cancellation & noise shielding.
  - 24,000 Hz linear PCM high-fidelity voice playback with gapless jitter-buffered scheduling.
- **Ultra-Natural Spoken Tamil (எதார்த்தமான பேச்சுத் தமிழ்) & English**:
  - Speaks everyday conversational Tamil (*"வணக்கம்! நான் லைகா ரியால்டில இருந்து பேசறேன்..."*) as spoken in Tamil Nadu.
  - Speaks friendly, human conversational English with natural contractions and warm pacing.
  - Auto-Detects whether the prospect speaks English, Tamil, or Tanglish.
- **Cold-Calling & Lead Qualification Dashboard**:
  - Live calculated conversion statistics: Answer Rate, Interest Rate, Qualification Rate, Hot Lead Rate.
  - Deterministic qualification scoring: **HOT** 🔥, **WARM** ☀️, **COLD** ❄️, **OPT-OUT** 🛑.
  - Complete Call History with turn-by-turn transcripts and automated CRM summaries.
  - 1-Click CSV Import and Export.
- **Compliance & Safety**:
  - Strict Do Not Call (DNC) enforcement: permanently suppresses phone numbers if customer requests opt-out.
  - Self-identifies as an AI assistant from Lyka Realty. Never pretends to be human or invents property prices.

---

## 📱 Real Phone Calling Setup (Twilio)

### Step 1: Twilio Account Credentials

1. Login to your [Twilio Console](https://console.twilio.com/).
2. Copy your **Account SID** and **Auth Token**.
3. Under **Phone Numbers → Manage → Active numbers**, get a phone number with **Voice** capabilities (e.g., `+12025550199` or your local country number).
   - *Note for Trial Accounts*: Twilio trial accounts require destination numbers to be verified under [Verified Caller IDs](https://console.twilio.com/us1/develop/phone-numbers/manage/verified).

### Step 2: Configure Environment

Add your Twilio credentials to `.env`:

```env
TWILIO_ACCOUNT_SID=ACc1844a8de1041f83a1ae67b25bf635b2
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_PHONE_NUMBER=+1xxxxxxxxxx
PUBLIC_BASE_URL=https://your-public-url.ngrok-free.app
```

*(You can also set your Twilio Phone Number directly from the web UI by clicking **"Twilio Real Call"** in the top navigation).*

---

## 🐍 Standalone Python FastAPI Backend (`backend/`)

For production Python deployments, a complete FastAPI service is provided in the `backend/` directory:

```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your Twilio credentials and ngrok URL
uvicorn main:app --reload --port 8000
```

### Exposing to the Internet via ngrok:

Since Twilio needs to reach your webhook from the internet, run ngrok:

```bash
ngrok http 8000
```

Copy the HTTPS forwarding URL (e.g., `https://abcdef.ngrok-free.app`) and set it as `PUBLIC_BASE_URL` in `.env`.

---

## 🚀 Full-Stack Node.js Quick Start (Port 3000)

The root server (`server.ts`) also includes the full Twilio REST API and Twilio Media Stream WebSocket handler:

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser:

1. Click **"Twilio Real Call"** in the header to verify your Twilio Phone Number.
2. Go to the **Leads** table or **Call Screen**.
3. Select **"Real Phone Call (Twilio)"**.
4. Enter your verified mobile phone number (e.g. `+91XXXXXXXXXX`).
5. Click **"Dial Real Phone"**.
6. Answer your phone and converse with Lyka AI in English or Tamil!

---

## 🏗️ Architecture

```
[ Real Mobile Phone (PSTN) ]
          ▲
          │ G.711 mu-law 8kHz
          ▼
   [ Twilio Voice ]
          ▲
          │ WebSocket Media Stream (`/api/twilio/media`)
          ▼
  [ Express / FastAPI Backend ]
          ▲
          │ PCM 16kHz / 24kHz
          ▼
 [ Gemini Live WebSocket (`gemini-3.8-live`) ]
          │
          ├─► Real-time Native PCM Audio Output
          ├─► Real-time Transcripts (Agent + Caller)
          └─► Structured Lead Qualification (`update_lead_info`)
```

---

## 📄 License

MIT License. Built with Google AI Studio, Twilio Voice, & Gemini Live.
